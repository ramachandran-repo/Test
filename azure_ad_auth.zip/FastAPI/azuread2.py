from msal import ConfidentialClientApplication, SerializableTokenCache, PublicClientApplication
from msal.exceptions import MsalServiceError
from exceptions import InvalidSecretException, InvalidTenantException, UnauthorizedClientException, OAuthTokenException
from requests.auth import AuthBase
import json
import os, atexit, msal

class MsalConfidentialClientAuth(AuthBase):

	def __init__(self, authority, client_id, client_secret, scopes=[], token_cache=SerializableTokenCache()):
		self.authority = authority
		self.client_id = client_id
		self.client_secret = client_secret
		self.token_cache = token_cache
		self.scopes = scopes
		print("msal authentication")
		if not self.scopes:
			self.scopes = ['{client_id}/.default'.format(client_id=self.client_id)]


		
		self.cache = msal.SerializableTokenCache()
		if os.path.exists("my_cache.bin"):
			print("cache reading")
			self.cache.deserialize(open("my_cache.bin", "r").read())
		
		self.token_cache = self.cache

		try:
			print(self.authority)
			self.app = PublicClientApplication(
				client_id='f63e3ef4-ec1a-488b-b0fd-c6e9a73664ee',
				authority=self.authority,
				token_cache=self.token_cache
				)
			print(self.__call__(self.app))
			'''
			resp = self.app.acquire_token_silent(scopes=self.scopes, account=None)
			if not resp:
				#logging.info("No suitable token exists in cache. Let's get a new one from AAD.")
				result = self.app.acquire_token_for_client(self.scopes)
				if "access_token" in result:
					# Calling graph using the access token
					new_token = result['access_token']
					print("new token")
					print(new_token)
			'''
		except(MsalServiceError):
			raise InvalidTenantException()

	def __call__(self, r):
		# Define the cache file path
		MSAL_CACHE_FILE = ".msal_cache.json"
		
		accounts = self.app.get_accounts()
		print(accounts)
		if accounts:
			resp = self.app.acquire_token_silent(account=accounts[0], scopes=self.scopes, timeout=5)
			print("resp for first request")
			print(resp)
			if resp is None:
				resp = self.app.acquire_token_interactive(scopes=self.scopes, account=accounts[0], timeout=5)
		else:
			resp = self.app.acquire_token_interactive(scopes=self.scopes, timeout=5)
			# Cache the account for future use
			if "access_token" in resp and "refresh_token" in resp:
				self.cache.add({
				"client_id": self.client_id,
				"home_account_id": resp.get("home_account_id"),
				"environment": self.authority,
				"realm": resp.get("realm"),
				"local_account_id": resp.get("local_account_id"),
				"username": resp.get("id_token_claims").get("preferred_username"),
				"authority_type": "MSSTS",
				"access_token": resp.get("access_token"),
				"id_token": resp.get("id_token"),
				"refresh_token": resp.get("refresh_token"),
				"expires_in": resp.get("expires_in"),
				"extended_expires_in": resp.get("extended_expires_in"),
				"token_type": "Bearer"
				})
			
		self.handle_token_generation_response(resp)

		# Use the access token to make API calls
		if "access_token" in resp:
		    access_token = resp["access_token"]
		    # (insert code here to make API calls using the access token)
		else:
		    print("Failed to acquire token silently or interactively")

		# Serialize the cache to the cache file
		if self.cache.has_state_changed:
			with open("my_cache.bin", "w") as cache_obj:
				cache_obj.write(self.cache.serialize())
		'''
		atexit.register(lambda:
		    open("my_cache.bin", "w").write(self.cache.serialize())
		    # Hint: The following optional line persists only when state changed
		    if self.cache.has_state_changed else None
		    )
		
		with open(MSAL_CACHE_FILE, "w") as cache_file:
		    cache_data = json.dumps(self.cache.serialize())
		    cache_file.write(cache_data)
		'''
		print(resp['access_token'])
		#r.headers['Authorization'] = "Bearer {access_token}".format(access_token=resp['access_token'])
		return r

	def handle_token_generation_response(self, resp):
		try:
			if resp['error'] == "unauthorized_client":
				raise UnauthorizedClientException()
			if resp['error'] == 'invalid_client':
				raise InvalidSecretException()

			raise OAuthTokenException("Azure token generation failed")
		except (KeyError):
			pass



