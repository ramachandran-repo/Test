import streamlit as st
from auth_test import BayerOAuth

bauth = BayerOAuth()
login_button = st.button("Login")
if login_button:
	bauth.get_auth()