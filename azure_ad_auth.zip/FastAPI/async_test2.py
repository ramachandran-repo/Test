import asyncio

async def q():
	print("method q")
	await asyncio.sleep(3)

async def a():
	print("method a")

async def main():
	await asyncio.gather(q(), a())

asyncio.run(main())