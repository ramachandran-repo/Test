import time

def q():
	print("method q")
	time.sleep(3)

def a():
	print("method a")

def main():
	q()
	a()

if __name__ == "__main__":
	main()