from msal import ConfidentialClientApplication, SerializableTokenCache
from msal.exceptions import MsalServiceError
from exceptions import InvalidSecretException, InvalidTenantException, UnauthorizedClientException, OAuthTokenException
from requests.auth import AuthBase

class MsalConfidentialClientAuth(AuthBase):

	def __init__(self, authority, client_id, client_secret, scopes=[], token_cache=SerializableTokenCache()):
		self.authority = authority
		self.client_id = client_id
		self.client_secret = client_secret
		self.token_cache = token_cache
		self.scopes = scopes
		print("msal authentication")
		if not self.scopes:
			self.scopes = ['{client_id}/.default'.format(client_id=self.client_id)]

		try:
			self.app = ConfidentialClientApplication(
				client_id=client_id,
				client_credential=client_secret,
				authority=self.authority,
				token_cache=self.token_cache
				)
			print(self.__call__(self.app))
			'''
			resp = self.app.acquire_token_silent(scopes=self.scopes, account=None)
			if not resp:
				#logging.info("No suitable token exists in cache. Let's get a new one from AAD.")
				result = self.app.acquire_token_for_client(self.scopes)
				if "access_token" in result:
					# Calling graph using the access token
					new_token = result['access_token']
					print("new token")
					print(new_token)
			'''
		except(MsalServiceError):
			raise InvalidTenantException()

	def __call__(self, r):
		resp = self.app.acquire_token_silent(scopes=self.scopes, account=None)
		if resp is None:
			resp = self.app.acquire_token_for_client(scopes=self.scopes)
		self.handle_token_generation_response(resp)
		print(resp)
		r.headers['Authorization'] = "Bearer {access_token}".format(access_token=resp['access_token'])
		return r

	def handle_token_generation_response(self, resp):
		try:
			if resp['error'] == "unauthorized_client":
				raise UnauthorizedClientException()
			if resp['error'] == 'invalid_client':
				raise InvalidSecretException()

			raise OAuthTokenException("Azure token generation failed")
		except (KeyError):
			pass



