import os
from azuread2 import MsalConfidentialClientAuth

class BayerOAuth:
	def __init__(self):
		self.azure_ad_client_id = "f63e3ef4-ec1a-488b-b0fd-c6e9a73664ee"
		self.azure_ad_client_secret = "hd88Q~glnTtZaaVmw.6UcCXl5f1_GiZrp1cyDaDP"
		self.azure_ad_tenant_id = "973fd83a-65bb-45e2-9888-cbdd94007565"

	def get_auth(self):
		print("get auth method")
		return MsalConfidentialClientAuth(
			authority = "https://login.microsoftonline.com/"+self.azure_ad_tenant_id,
			client_id = self.azure_ad_client_id,
			client_secret = self.azure_ad_client_secret)

if __name__ == "__main__":
	bo = BayerOAuth()
	bo.get_auth()