import streamlit as st
import pandas as pd
import ceb_planner as cp

col_names = ['Campaign Name', 'CEC', 'Type', 'Status', 'Start Date', 'End Date', 'Owner']
test_data = [['test campaign', 'test CEC', 'CEC', 'Planned', '22.11.2023', '21.11.2024', 'test user'], 
			['test campaign2', 'test CEC', 'CEC', 'Planned', '22.11.2023', '21.11.2024', 'test user']]

df = pd.DataFrame(test_data, columns = col_names)
print(df)

st.header("NBO")

tab1, tab2, tab3, tab4, tab5 = st.tabs(["Home", "Campaign", "Storyline", "Rules", "Dashboard"])

with tab1:
	st.header("Campaign planner")
	#st.table(df)
	st.dataframe(df)
with tab2:
	cp.ceb_planner()