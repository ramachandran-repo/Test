import streamlit as st
import datetime
import pandas as pd

def ceb_planner():
	today = datetime.datetime.now()
	next_year = today.year + 1
	jan_1 = datetime.date(next_year, 1, 1)
	dec_31 = datetime.date(next_year, 12, 31)
	st.header("CEB Planner")
	st.markdown("""---""")

	col1, col2, col3, col4 = st.columns(4)
	col1.selectbox("Segment", ("Select Segment", "test1", "test2"))
	col3.date_input("CEB Start date", format="DD/MM/YYYY")
	col4.date_input("CEB End date", format="DD/MM/YYYY")

	col1, col2, col3, col4 = st.columns(4)
	col1.selectbox("CEB Name", ("Select CEB Name", "CEB1", "CEB2"))
	col2.selectbox("Segment Size", ("Select Segment Size", "s1", "s2"))
	col3.selectbox("Segment Value", ("Select Segment Value", "S1", "S2"))
	col4.selectbox("Potential", ("Select Potential", "P1", "P2"))
	
	col1, col2, col3 = st.columns([1,1,2])

	with col1:
		st.selectbox("Country", ("Select Country", "C1", "C2"))
		st.selectbox("Brand", ("Select Brand", "C1", "C2"))
		st.selectbox("Speciality", ("Select Speciality"))
	with col2:
		st.selectbox("Threapeutic area", ("Select Threapeutic area", "T1", "T2"))
		st.selectbox("Indication", ("Select Indication", "T1", "T2"))
	col3.text_area("Priority Opportunity", height=200)
	
	col1, col3 = st.columns([2,2])
	with col1:
		st.text_area("Adoption Ladder (FROM)")
		st.text_area("Communication Objective", height = 100)
	with col3:
		st.text_area("Adoption Ladder (TO)")
		st.text_area("PGMI", height = 100)

	col1, col2, col3, col4 = st.columns(4)
	submit_button = col1.button("Submit")
	

